#include "Debug_PI.h"
#include "Texture_PI.h"
#include "SoundSystem.h"
#include "MapSystem.h"

Debug_PI* Debug_PI::c_pointer = new Debug_PI();

Debug_PI::Debug_PI()
{
}

Debug_PI::~Debug_PI()
{

}

void Debug_PI::Init()
{
	dt = 0;
	Camera_PI camera;
	camera.Init(Vector3(10, 0, 0), Vector3(), Vector3(0, 1, 0), 0, 0);
	Render_PI::pointer()->Camera_Set(camera);
	MapSystem::pointer()->LoadMap("Data\\Map\\TestMap.csv", "Test");
	testSubject = new SpriteAnimation("Data\\TestSubject.tga", 1, 8);
	if (testSubject)
	{
		testSubject->m_anim = new Animation();
		testSubject->m_anim->Set(0, 7, 1, 1.0f, true);
	}
}

void Debug_PI::Update(double dt)
{
	testSubject->Update(dt);
	this->dt += dt;

}

void Debug_PI::Render()
{
	MapSystem::pointer()->RenderMap("Test");

	Render_PI::pointer()->modelStack_Set(true);
	Render_PI::pointer()->RenderMeshIn2D(Texture::Get("XX"), false, Render_PI::Window_Scale()*0.5, Render_PI::Window_Scale());
	Render_PI::pointer()->modelStack_Set(false);
}

void Debug_PI::Exit()
{

}
