#ifndef DEBUG_PI
#define DEBUG_PI
#include "Main_Shaft.h"

class Debug_PI :public Scene
{
public:
	static Debug_PI* pointer(){ return c_pointer; };
	virtual void Init();
	virtual void Update(double dt);
	virtual void Render();
	virtual void Exit();
private:
	Debug_PI();
	~Debug_PI();
	float dt;
	Vector3 Pos;
	Vector3 Dir;
	static Debug_PI* c_pointer;
	SpriteAnimation* testSubject;
};


#endif