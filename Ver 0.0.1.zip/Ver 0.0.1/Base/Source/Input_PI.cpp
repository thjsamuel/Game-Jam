#include"Input_PI.h"


Input_PI* Input_PI::m_pointer = new Input_PI();

void Input_PI::Init()
{
	for (int i = Nothing + 1; i < All_Control; i++)
	{
		IsBeingPressed[i] = false;
		HaveBeenPressed[i] = false;
	}
}

void Input_PI::Clear()
{
	for (int i = Nothing + 1; i < All_Control; i++)
	{
		HaveBeenPressed[i] = false;
	}
}

void Input_PI::Update(double dt)
{
	Clear();
	/*
	if (Application::IsKeyPressed(VK_SHIFT))
	{
		IsBeingPressed[Run] = true;
	}
	else if (IsBeingPressed[Run] == true)
	{
		IsBeingPressed[Run] = false;
		HaveBeenPressed[Run] = true;
	}
	*/

	if (Application::IsKeyPressed('A'))
	{
		IsBeingPressed[A_] = true;
	}
	else if (IsBeingPressed[A_] == true)
	{
		IsBeingPressed[A_] = false;
		HaveBeenPressed[A_] = true;
	}
	if (Application::IsKeyPressed('S'))
	{
		IsBeingPressed[S_] = true;
	}
	else if (IsBeingPressed[S_] == true)
	{
		IsBeingPressed[S_] = false;
		HaveBeenPressed[S_] = true;
	}
	if (Application::IsKeyPressed('W'))
	{
		IsBeingPressed[W_] = true;
	}
	else if (IsBeingPressed[W_] == true)
	{
		IsBeingPressed[W_] = false;
		HaveBeenPressed[W_] = true;
	}
	if (Application::IsKeyPressed('D'))
	{
		IsBeingPressed[D_] = true;
	}
	else if (IsBeingPressed[D_] == true)
	{
		IsBeingPressed[D_] = false;
		HaveBeenPressed[D_] = true;
	}
}


void Input_PI::Render()
{

}

void Input_PI::Exit()
{
	delete m_pointer;
}
