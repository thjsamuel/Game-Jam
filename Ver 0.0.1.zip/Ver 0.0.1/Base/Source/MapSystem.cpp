#include "MapSystem.h"
#include "Texture_PI.h"

MapSystem* MapSystem::c_pointer = new MapSystem();

std::map<std::string, Map*> MapSystem::AllMaps;

void Map::Fill()
{
	for (int row = 0; row < 20; row++)
	{
		for (int col = 0; col < 20; col++)
		{
			this->MapTile[row][col] = "0";
		}
	}
}

void MapSystem::Init()
{

}

void MapSystem::Exit()
{
	if (c_pointer != nullptr)
	{
		AllMaps.clear();
		delete c_pointer;
		c_pointer = nullptr;
	}
}

bool MapSystem::LoadMap(string FileName, string MapName)
{
	std::ifstream file(FileName);	 // declare file stream: 
	std::string Raw_Data;	//the entire line WITH commas
	std::stringstream Datas;//Datas to process
	std::string Porcessed_Data; //individual values
	Map* created_map = new Map();
	created_map->Fill();
	int Row = 0;
	int Col = 0;
	if (file.is_open())
	{
		while (getline(file, Raw_Data)) //read entire line
		{
			Datas << Raw_Data;    //create istringstream for parsing
			while (getline(Datas, Porcessed_Data, ',')) //parse for commas
			{
				created_map->MapTile[Row][Col] = Porcessed_Data;
				Col++;
				if (Col > 19)
				{
					delete created_map;
					return false;
				}
			}
			Row++;
			if (Row > 19)
			{
				delete created_map;
				return false;
			}
			Datas.clear();
			Col = 0;
		}
	}
	else
	{
		delete created_map;
		return false;
	}

	std::pair<std::map<std::string, Map*>::iterator, bool> ret;
	ret = AllMaps.insert(std::pair<std::string, Map*>(MapName, created_map));
	if (ret.second == false) {

		delete created_map;
		return false;
	}

	return true;
}

Map* MapSystem::GetMap(string MapName)
{
	std::map<std::string, Map*>::iterator it;
	it = AllMaps.find(MapName);
	if (it == AllMaps.end())
	{
		return nullptr;
		cout << "Invalid GetMap Named " << MapName << " ... " << endl;
	}
	return it->second;
}

void MapSystem::RenderMap(string MapName)
{
	Map* Tmp_Map = GetMap(MapName);
	Vector3 tileSize = Render_PI::Window_Scale()*0.05;
	if (Tmp_Map)
	{
		for (int row = 0; row < 20; row++)
		{
			for (int col = 0; col < 20; col++)
			{
				Render_PI::pointer()->modelStack_Set(true);
				Render_PI::pointer()->RenderMeshIn2D(Texture::Get(Tmp_Map->MapTile[row][col]), false, Vector3(tileSize.x*(col), tileSize.y * (19-row), -5) + (tileSize*0.5), tileSize);
				Render_PI::pointer()->modelStack_Set(false);
			}
		}
	}
	else
	{
		cout << "Invalid RenderMap Named "<<MapName<<" ... " << endl;
	}
}
