#ifndef MAPSYSTEM
#define MAPSYSTEM

#include "Main_Shaft.h"

class Map
{
public:
	string MapTile[20][20];
	void Fill();
};

class MapSystem
{
public:
	virtual void Init();
	static MapSystem* pointer(){ return c_pointer; };
	virtual bool LoadMap(string FileName, string MapName);
	virtual Map* GetMap(string MapName);
	virtual void RenderMap(string MapName);
	virtual void Exit();
private:
	MapSystem(){};
	~MapSystem(){};
	static std::map<std::string, Map*> AllMaps;
	static MapSystem* c_pointer;
};

#endif