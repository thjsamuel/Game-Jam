#include "SoundSystem.h"
#include "Input_PI.h"

SoundSystem* SoundSystem::c_pointer = new SoundSystem();

void SoundSystem::Init()
{
	engine = createIrrKlangDevice();
	PlayerPos = Vector3();
	PlayerDir = Vector3(0,0,1);
	if (!engine)
	{
		cout << "Sound Engine Failed To Work!" << endl;
	}
}

void SoundSystem::SoundPlay(string fileline, bool Effect3D, string SoundName, Vector3 Pos)
{

	if (Effect3D)
	{
		SoundType* NewSound = new SoundType();
		NewSound->music = engine->play3D(fileline.c_str(), vec3df(0, 0, 0), true, false, true);
		NewSound->SoundName = SoundName;
		NewSound->Pos = vec3df(Pos.x, Pos.y, Pos.z);
		AllSounds.push_back(NewSound);
	}
	else
	{
		engine->play2D(fileline.c_str(), true);
	}
}

void SoundSystem::SoundUpdate(string SoundName, Vector3 Pos)
{
	SoundType* CurrentSound = nullptr;
	for (vector<SoundType*>::iterator SoundPoint = AllSounds.begin(); SoundPoint != AllSounds.end(); SoundPoint++)
	{
		if (((SoundType*)*SoundPoint)->SoundName == SoundName)
		{
			CurrentSound = ((SoundType*)*SoundPoint);
			CurrentSound->Pos = vec3df(Pos.x, Pos.y, Pos.z);
			break;
		}
	}
	if (CurrentSound == nullptr)
	{
		cout << SoundName << " failed to find" << endl;
	}
}

void SoundSystem::Update(double dt)
{
	//Listener Dir+Pos
	engine->setListenerPosition(vec3df(PlayerPos.x, PlayerPos.y, PlayerPos.z), vec3df(PlayerDir.x, PlayerDir.y, PlayerDir.z));

	vector<SoundType*> NewArray;
	//Sound Pos
	for (vector<SoundType*>::iterator SoundPoint = AllSounds.begin(); SoundPoint != AllSounds.end(); SoundPoint++)
	{
		SoundType* CurrentSound = (SoundType*)*SoundPoint;

		if (CurrentSound->music)
		{
			if (CurrentSound->music->isFinished())
			{
				CurrentSound->music->drop();
				delete CurrentSound;
			}
			else
			{
				CurrentSound->music->setPosition(CurrentSound->Pos);
				NewArray.push_back(CurrentSound);
			}
		}
	}
}

void SoundSystem::PlayerUpdate(Vector3 Pos, Vector3 Dir)
{
	PlayerPos = Pos;
	PlayerDir = Dir.Normalized();
	if (PlayerDir == Vector3())
	{
		PlayerDir = Vector3(0, 0, 0.1);
	}

}

void SoundSystem::Exit()
{
	if (c_pointer != nullptr)
	{
		engine->drop();
		for (vector<SoundType*>::iterator SoundPoint = AllSounds.begin(); SoundPoint != AllSounds.end(); SoundPoint++)
		{
			SoundType* CurrentSound = (SoundType*)*SoundPoint;
			CurrentSound->music->drop();
			delete CurrentSound;
		}
		delete c_pointer;
		c_pointer = nullptr;
	}
}
