#ifndef SOUNDSYSTEM
#define SOUNDSYSTEM
#include "Main_Shaft.h"

class SoundType
{
public:
	ISound* music;
	string SoundName;
	vec3df Pos;
};

class SoundSystem
{
public:
	static SoundSystem* pointer(){ return c_pointer; };
	virtual void Init();
	virtual void Update(double dt);
	virtual void SoundPlay(string fileline, bool Effect3D = false, string SoundName = "", Vector3 Pos = Vector3());
	virtual void SoundUpdate(string SoundName, Vector3 Pos);
	virtual void PlayerUpdate(Vector3 Pos, Vector3 Dir);
	virtual void Exit();
private:
	SoundSystem(){};
	~SoundSystem(){};
	Vector3 PlayerPos;
	Vector3 PlayerDir;
	ISoundEngine* engine;
	vector<SoundType*> AllSounds;
	static SoundSystem* c_pointer;
};


#endif