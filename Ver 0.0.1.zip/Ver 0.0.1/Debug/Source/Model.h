#ifndef MODEL
#define MODEL

class Model
{
public:
	virtual void Init() = 0;
	virtual void Exit() = 0;
};
#endif