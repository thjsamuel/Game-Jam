#ifndef SYSTEM
#define SYSTEM

class System
{
public:
	virtual void Update(float dt) = 0;
};

#endif