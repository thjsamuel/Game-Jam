creating SoundSystem
Extracting it into additional functions

